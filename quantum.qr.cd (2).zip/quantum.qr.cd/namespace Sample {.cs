namespace Sample {
    open Microsoft.Quantum.Arrays;
    open Microsoft.Quantum.Diagnostics;
    open Microsoft.Quantum.Math;
    open Microsoft.Quantum.Intrinsic;

    @EntryPoint()a
    operation PhaseLine(image:IntAsDouble[]) : Unit {
        use q = Qubit();
        for i in 0 .. Length(image) - 1 {
            // Normalize the pixel value to be between 0 and 1.
            let normalizedPixel = image[i] / 255.0;

            // Calculate the phase rotation angle.
            let angle = 2.0 * PI() * normalizedPixel;

            // Apply the phase rotation to the qubit.
            R1(angle, q);

            // Display the current state of the qubit using the 'DumpMachine' function.
            Message($"State after applying phase rotation for pixel {i}:");
            DumpMachine();
        }
        Reset(q);
    }
}